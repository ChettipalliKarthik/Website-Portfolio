function toggleMenu(){
    const menu=document.querySelcetor(".menu-links");
    const icon=document.querySelcetor(".hamburger-icon");
    menu.classList.toggle("open");
    icon.classList.toggle("open");
}